// scripts/generators/charactermancer.js
const { HandlebarsApplicationMixin, ApplicationV2 } = foundry.applications.api;
import { skillAttrMap } from "../helpers/config.js";
import { ScrollPreserveMixin } from "../helpers/scroll-mixin.js";

export class ReignCharactermancer extends ScrollPreserveMixin(HandlebarsApplicationMixin(ApplicationV2)) {
  static DEFAULT_OPTIONS = {
    id: "reign-charactermancer",
    classes: ["reign", "charactermancer", "app-v2"],
    tag: "form",
    window: { 
      title: "Reign: Forge Your Legend", 
      resizable: true, 
      width: 950, 
      height: 800
    },
    position: { width: 950, height: 800 },
    // V14 Architecture: Bind actions directly to the prototype
    actions: {
      selectPath: this.prototype._onSelectPath,
      adjustStat: this.prototype._onAdjustStat,
      toggleUpgrade: this.prototype._onToggleUpgrade,
      addCustomSkill: this.prototype._onAddCustomSkill,
      removeCustomSkill: this.prototype._onRemoveCustomSkill,
      changeBudget: this.prototype._onChangeBudget,
      changeTable: this.prototype._onChangeTable,
      removeItem: this.prototype._onRemoveItem,
      finishCharacter: this.prototype._onFinishCharacter,
      rollTheBones: this.prototype._onRollTheBones,
      selectWasteChart: this.prototype._onSelectWasteChart,
      acceptFate: this.prototype._onAcceptFate,
      selectSchool: this.prototype._onSelectSchool
    }
  };

  static PARTS = {
    main: { template: "systems/reign/templates/apps/charactermancer.hbs" }
  };

  constructor(options = {}) {
    super(options);
    this.actor = options.document;
    this.creationPath = null; 
    
    this.draftCharacter = {
      name: "Unnamed Legend",
      pointsMax: 85, 
      pointsSpent: 0,
      attributes: { body: 1, coordination: 1, sense: 1, knowledge: 1, command: 1, charm: 1 }, 
      skills: {},
      sorcery: { value: 0, expert: false, master: false },
      school: null,       // Selected magical school — populated from the table's schools array
      customSkills: {}, 
      wealth: 0,
      advantages: [],
      problems: [],
      martialPaths: [],
      esoterica: [],
      spells: [],
      weapons: [],
      armor: [],
      shields: [],
      gear: []
    };

    this.oneRollState = {
      rolled: false,
      dice: [],
      sets: [],
      waste: [],
      wasteChoices: {},
      biography: [],
      selectedTable: ""
    };
    this.oneRollTable = null;

    for (const skill of Object.keys(skillAttrMap)) {
      const isNative = skill === "languageNative";
      this.draftCharacter.skills[skill] = {
        // V14 FIX: Native Language starts with 1D and is upgraded to a Master Die
        value: isNative ? 1 : 0,
        expert: false,
        master: isNative 
      };
    }
  }

  async close(options={}) {
      if (this.actor?.system?.creationMode) {
          await this.actor.update({ "system.creationMode": false });
      }
      return super.close(options);
  }

  _onRender(context, options) {
      super._onRender(context, options);
      const dropZone = this.element.querySelector(".cm-drop-zone");
      if (dropZone) {
          dropZone.addEventListener("dragover", (ev) => {
              ev.preventDefault();
              dropZone.style.background = "rgba(1, 87, 155, 0.1)"; 
              dropZone.style.borderColor = "#01579b";
          });
          dropZone.addEventListener("dragleave", (ev) => {
              ev.preventDefault();
              dropZone.style.background = "rgba(0,0,0,0.02)"; 
              dropZone.style.borderColor = "#ccc";
          });
          dropZone.addEventListener("drop", async (ev) => {
              ev.preventDefault();
              dropZone.style.background = "rgba(0,0,0,0.02)";
              dropZone.style.borderColor = "#ccc";
              await this._handleItemDrop(ev);
          });
      }
  }

  async _prepareContext(options) {
    const context = await super._prepareContext(options);
    context.actor = this.actor;
    context.draft = this.draftCharacter;

    this.draftCharacter.pointsMax = game.settings.get("reign", "campaignBudget") || 85;
    context.costs = { attribute: 5, skill: 1, ed: 1, md: 5 };
    
    this._calculatePoints();
    context.pointsRemaining = this.draftCharacter.pointsMax - this.draftCharacter.pointsSpent;
    
    context.pathSelected = !!this.creationPath;
    context.isOneRoll = this.creationPath === "oneroll";
    context.isPointBuy = this.creationPath === "pointbuy";

    const formatGains = (stage) => {
        const gains = [];
        if (stage.attributes) Object.entries(stage.attributes).forEach(([k, v]) => gains.push(`+${v} ${k.toUpperCase()}`));
        if (stage.skills) Object.entries(stage.skills).forEach(([k, v]) => gains.push(`+${v} ${k.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}`));
        if (stage.customSkills) stage.customSkills.forEach(cs => gains.push(`+${cs.value || 1} ${cs.name}`));
        if (stage.wealth) gains.push(`+${stage.wealth} Wealth`);
        if (stage.advantages) stage.advantages.forEach(a => gains.push(`${a.name}`));
        if (stage.martialPaths) stage.martialPaths.forEach(m => gains.push(`${m.name}`));
        if (stage.esoterica) stage.esoterica.forEach(e => gains.push(`${e.name}`));
        if (stage.spells) stage.spells.forEach(s => gains.push(`${s.name}`));
        if (stage.weapons) stage.weapons.forEach(w => gains.push(`${w.name}`));
        if (stage.armor) stage.armor.forEach(a => gains.push(`${a.name}`));
        if (stage.shields) stage.shields.forEach(sh => gains.push(`${sh.name}`));
        if (stage.gear) stage.gear.forEach(g => gains.push(`${g.name}`));
        if (stage.special) gains.push(`Special: ${stage.special}`);
        return gains.join(" | ");
    };

    if (context.isOneRoll) {
        const tablesSetting = game.settings.get("reign", "oneRollTables") || `systems/${game.system.id}/data/oneroll-default.json`;
        const paths = tablesSetting.split(",").map(p => p.trim()).filter(p => p);
        
        context.availableTables = {};
        paths.forEach(path => {
            const filename = path.split('/').pop().replace('.json', '').replace(/-/g, ' ').replace('oneroll', 'one roll');
            context.availableTables[path] = filename.replace(/\b\w/g, l => l.toUpperCase()); 
        });

        context.selectedTable = this.oneRollState.selectedTable || paths[0];
        context.oneRoll = this.oneRollState;

        if (this.oneRollState.rolled && this.oneRollTable) {
            context.oneRollDisplay = {
                sets: this.oneRollState.sets.map(s => {
                    const pathData = this.oneRollTable.sets[s.height];
                    const pathName = pathData?.path || "Unknown Path";
                    
                    let aggregatedGains = [];
                    for (let w = 2; w <= s.width; w++) {
                        const stage = pathData?.stages[w.toString()];
                        if (stage) {
                            const fg = formatGains(stage);
                            if (fg) aggregatedGains.push(`(W${w}) ` + fg);
                        }
                    }
                    return { 
                        label: `${s.width}x${s.height}: ${pathName}`,
                        details: aggregatedGains 
                    };
                }),
                waste: this.oneRollState.waste.map(w => {
                    const selectedChart = this.oneRollState.wasteChoices[w];
                    let details = "";
                    if (selectedChart) {
                        const stage = this.oneRollTable.waste[selectedChart]?.results[w];
                        if (stage) details = formatGains(stage);
                    }
                    return {
                        die: w,
                        selected: selectedChart,
                        details: details,
                        options: ["A", "B", "C"].map(c => ({
                            chart: c,
                            label: this.oneRollTable.waste[c]?.results[w]?.label || "Unknown",
                            active: selectedChart === c
                        }))
                    };
                })
            };
        }
    }

    context.skillGroups = {};
    for (const [sKey, aKey] of Object.entries(skillAttrMap)) {
      if (!context.skillGroups[aKey]) context.skillGroups[aKey] = [];
      let label = sKey.replace(/_/g, " ");
      if (sKey === "languageNative") label = "Language (Native)";
      if (sKey === "taste_touch_smell") label = "Taste/Touch/Smell";
      context.skillGroups[aKey].push({
        key: sKey, label: label, data: this.draftCharacter.skills[sKey],
        isNative: sKey === "languageNative", isCustom: false, type: "skill"
      });
    }

    for (const [cKey, cSkill] of Object.entries(this.draftCharacter.customSkills)) {
        const aKey = cSkill.attribute;
        if (!context.skillGroups[aKey]) context.skillGroups[aKey] = [];
        context.skillGroups[aKey].push({
            key: cKey, label: cSkill.name, data: cSkill,
            isNative: false, isCustom: true, type: "customSkill"
        });
    }

    for (const group in context.skillGroups) {
        context.skillGroups[group].sort((a, b) => a.label.localeCompare(b.label));
    }

    // ── SCHOOL PICKER ─────────────────────────────────────────────────────
    // Load available schools from the active table JSON.
    // Both one-roll and point-buy paths share the same source JSON so
    // schools are available regardless of creation method.
    // If the table has no schools key, the picker is gracefully hidden.
    context.hasSorcery = this.draftCharacter.sorcery.value > 0;
    context.availableSchools = [];
    context.selectedSchool = this.draftCharacter.school;

    if (context.hasSorcery) {
        const tablesSetting = game.settings.get("reign", "oneRollTables") || `systems/${game.system.id}/data/oneroll-default.json`;
        const primaryPath = tablesSetting.split(",").map(p => p.trim()).filter(p => p)[0];
        if (primaryPath) {
            const table = await this._loadOneRollTable(primaryPath);
            if (table?.schools?.length) {
                context.availableSchools = table.schools.map(s => ({
                    ...s,
                    isSelected: this.draftCharacter.school?.id === s.id
                }));
            }
        }
    }

    return context;
  }

  _calculatePoints() {
    let spent = 0;
    const costAttr = 5, costSkill = 1, costED = 1, costMD = 5;

    // Attributes
    for (const val of Object.values(this.draftCharacter.attributes)) {
      if (val > 1) spent += ((val - 1) * costAttr);
    }

    // Core Skills
    for (const [key, skill] of Object.entries(this.draftCharacter.skills)) {
      let isNativeLang = (key === "languageNative");
      
      // V14 FIX: The first regular die of Native Language is completely free.
      // Any additional dice purchased cost the standard 1 point.
      let chargeableDice = isNativeLang ? Math.max(0, skill.value - 1) : skill.value;
      spent += (chargeableDice * costSkill); 
      
      // The Master Die upgrade for Native Language is completely free.
      if (skill.expert && !isNativeLang) spent += costED; 
      if (skill.master && !isNativeLang) spent += costMD; 
    }

    // Sorcery
    spent += (this.draftCharacter.sorcery.value * costSkill);
    if (this.draftCharacter.sorcery.expert) spent += costED;
    if (this.draftCharacter.sorcery.master) spent += costMD;

    // Custom Skills
    for (const skill of Object.values(this.draftCharacter.customSkills)) {
        spent += (skill.value * costSkill);
        if (skill.expert) spent += costED;
        if (skill.master) spent += costMD;
    }

    // Wealth Base
    spent += this.draftCharacter.wealth;
    
    // Perks, Paths, and Magic
    for (const item of this.draftCharacter.advantages) spent += (Number(item.system.cost) || 0);
    for (const item of this.draftCharacter.martialPaths) spent += (Number(item.system.rank) || 1);
    for (const item of this.draftCharacter.esoterica) spent += (Number(item.system.rank) || 1);

    // Equipment wealthCost (Possessions)
    for (const item of this.draftCharacter.weapons) spent += (Number(item.system.wealthCost) || 0);
    for (const item of this.draftCharacter.armor) spent += (Number(item.system.wealthCost) || 0);
    for (const item of this.draftCharacter.shields) spent += (Number(item.system.wealthCost) || 0);
    for (const item of this.draftCharacter.gear) spent += (Number(item.system.wealthCost) || 0);

    // Spell Logic (Attuned vs Free vs Normal)
    const isAttuned = this.draftCharacter.advantages.some(a => /attuned/i.test(a.name));
    let attunedSpellClaimed = false;

    const spellsByIntensity = { 1: [], 2: [], 3: [], 4: [], 5: [], 6: [], 7: [], 8: [], 9: [], 10: [] };
    
    for (const spell of this.draftCharacter.spells) {
        if (isAttuned && !attunedSpellClaimed && /permanent attunement/i.test(spell.name)) {
            attunedSpellClaimed = true;
            continue; 
        }
        const intensity = Math.max(1, Math.min(10, Number(spell.system.intensity) || 1));
        spellsByIntensity[intensity].push(spell);
    }

    for (let i = 1; i <= 10; i++) {
        const count = spellsByIntensity[i].length;
        if (count === 0) continue;

        if (i === 1) {
            spent += Math.ceil(count / 2);
        } else {
            const pairs = Math.floor(count / 2);
            const remainder = count % 2;
            spent += (pairs * i) + (remainder * (i - 1));
        }
    }

    this.draftCharacter.pointsSpent = spent;
  }

  async _loadOneRollTable(path) {
      if (this.oneRollTable && this.oneRollTable._path === path) return this.oneRollTable;
      
      if (path.startsWith("http://") || path.startsWith("https://")) {
          ui.notifications.error(game.i18n.localize("REIGN.CM.Errors.CustomTableSecurity"));
          return null;
      }

      try {
          const response = await fetch(path);
          if (!response.ok) {
              ui.notifications.error(`${game.i18n.localize("REIGN.CM.Errors.TableNotFound")} ${path}`);
              return null;
          }

          let table;
          try {
              table = await response.json();
          } catch (parseErr) {
              console.error("Reign | One-Roll Table parse error", parseErr);
              ui.notifications.error(`${game.i18n.localize("REIGN.CM.Errors.JsonParseError")} ${path}`);
              this._postTableValidationError(path, [`JSON parse failed: ${parseErr.message}`], []);
              return null;
          }

          // F2: Structural validation — collect errors and warnings separately.
          // Errors block loading; warnings are advisory only.
          const errors = [];
          const warnings = [];

          // Required top-level keys
          if (!table.tableName)  errors.push("Missing required field: \"tableName\"");
          if (!table.sets)       errors.push("Missing required field: \"sets\"");
          if (!table.waste)      errors.push("Missing required field: \"waste\"");

          // Advisory: schools key absent is fine but worth noting
          if (!table.schools) warnings.push("No \"schools\" key found — school picker will be hidden during character creation");

          // Validate sets structure if present
          if (table.sets && typeof table.sets === "object") {
              const setKeys = Object.keys(table.sets);
              if (setKeys.length === 0) {
                  errors.push("\"sets\" is empty — no life path results defined");
              } else {
                  // Check a sample of set entries for expected structure
                  let malformedSets = 0;
                  for (const [setKey, setVal] of Object.entries(table.sets)) {
                      if (!setVal || typeof setVal !== "object") { malformedSets++; continue; }
                      if (!setVal.stages && !setVal.label && !setVal.description) malformedSets++;
                  }
                  if (malformedSets > 0) {
                      warnings.push(`${malformedSets} set entry(ies) appear malformed — expected objects with "label", "description", or "stages"`);
                  }
              }
          } else if (table.sets) {
              errors.push("\"sets\" must be an object keyed by Width-Height (e.g. \"2x10\")");
          }

          // Validate waste structure if present
          if (table.waste && !Array.isArray(table.waste) && typeof table.waste !== "object") {
              errors.push("\"waste\" must be an array or object of waste results");
          }

          // Hard stop on errors
          if (errors.length > 0) {
              this._postTableValidationError(path, errors, warnings);
              return null;
          }

          // Soft warnings — post to chat but continue loading
          if (warnings.length > 0) {
              this._postTableValidationWarning(path, warnings);
          }

          table._path = path;
          this.oneRollTable = table;
          return table;

      } catch (e) {
          console.error("Reign | Failed to load One-Roll table", e);
          ui.notifications.error(`${game.i18n.localize("REIGN.CM.Errors.JsonParseError")} ${path}`);
          return null;
      }
  }

  /**
   * F2: Posts a structured error card to chat when the One-Roll Table fails validation.
   * Blocking — table will not load.
   */
  _postTableValidationError(path, errors, warnings) {
      const errorList = errors.map(e => `<li><i class="fas fa-times-circle"></i> ${e}</li>`).join("");
      const warnList  = warnings.length > 0
          ? `<ul class="reign-validation-list warn">${warnings.map(w => `<li><i class="fas fa-exclamation-triangle"></i> ${w}</li>`).join("")}</ul>`
          : "";
      ChatMessage.create({
          content: `<div class="reign-chat-card reign-card-danger">
              <h3 class="reign-msg-danger"><i class="fas fa-times-circle"></i> One-Roll Table Failed to Load</h3>
              <p class="reign-text-small reign-text-muted">${path}</p>
              <ul class="reign-validation-list error">${errorList}</ul>
              ${warnList}
              <p class="reign-text-small reign-text-muted"><i class="fas fa-info-circle"></i> Fix the JSON and reload the Charactermancer.</p>
          </div>`
      });
  }

  /**
   * F2: Posts an advisory warning card to chat when the table loads but has structural issues.
   * Non-blocking — table loads normally.
   */
  _postTableValidationWarning(path, warnings) {
      const warnList = warnings.map(w => `<li><i class="fas fa-exclamation-triangle"></i> ${w}</li>`).join("");
      ChatMessage.create({
          content: `<div class="reign-chat-card reign-card-warn">
              <h3 class="reign-msg-info"><i class="fas fa-exclamation-triangle"></i> One-Roll Table Loaded with Warnings</h3>
              <p class="reign-text-small reign-text-muted">${path}</p>
              <ul class="reign-validation-list warn">${warnList}</ul>
          </div>`
      });
  }

  async _findItem(name, type) {
      const lowerName = name.toLowerCase();
      let found = game.items.find(i => i.type === type && i.name.toLowerCase() === lowerName);
      if (found) return found;

      for (const pack of game.packs.values()) {
          if (pack.metadata.type === "Item") {
              const index = await pack.getIndex({fields: ["type", "name"]});
              const match = index.find(i => i.type === type && i.name.toLowerCase() === lowerName);
              if (match) {
                  found = await pack.getDocument(match._id);
                  return found;
              }
          }
      }
      return null;
  }

  async _applyOneRollSets(table) {
      this.draftCharacter.attributes = { body: 2, coordination: 2, sense: 2, knowledge: 2, command: 2, charm: 2 };
      for (const skill of Object.keys(skillAttrMap)) {
          const isNative = skill === "languageNative";
          this.draftCharacter.skills[skill] = { value: isNative ? 1 : 0, expert: false, master: isNative };
      }
      this.draftCharacter.customSkills = {};
      this.draftCharacter.sorcery = { value: 0, expert: false, master: false };
      this.draftCharacter.school = null;
      this.draftCharacter.wealth = 0;
      this.draftCharacter.advantages = [];
      this.draftCharacter.problems = [];
      this.draftCharacter.martialPaths = [];
      this.draftCharacter.esoterica = [];
      this.draftCharacter.spells = [];
      this.draftCharacter.weapons = [];
      this.draftCharacter.armor = [];
      this.draftCharacter.shields = [];
      this.draftCharacter.gear = [];
      this.oneRollState.biography = [];

      for (const set of this.oneRollState.sets) {
          const heightData = table.sets[set.height];
          if (!heightData) continue;
          for (let w = 2; w <= set.width; w++) {
              const stage = heightData.stages[w.toString()];
              if (stage) await this._applyStageGains(stage);
          }
      }

      for (const wDie of this.oneRollState.waste) {
          const choice = this.oneRollState.wasteChoices[wDie];
          if (choice) {
              const wasteData = table.waste[choice]?.results[wDie];
              if (wasteData) await this._applyStageGains(wasteData);
          }
      }

      this._calculatePoints();
  }

  async _applyStageGains(stage) {
      // D3: Collect gains for this stage so they can be appended to the biography entry.
      const gainParts = [];

      if (stage.attributes) Object.entries(stage.attributes).forEach(([k, v]) => {
          gainParts.push(`+${v} ${k.charAt(0).toUpperCase() + k.slice(1)}`);
      });
      if (stage.skills) Object.entries(stage.skills).forEach(([k, v]) => {
          gainParts.push(`+${v} ${k.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}`);
      });
      if (stage.customSkills) stage.customSkills.forEach(cs => {
          gainParts.push(`+${cs.value || 1} ${cs.name}`);
      });
      if (stage.wealth) gainParts.push(`+${stage.wealth} Wealth`);
      if (stage.advantages) stage.advantages.forEach(a => gainParts.push(a.name));
      if (stage.martialPaths) stage.martialPaths.forEach(m => gainParts.push(m.name));
      if (stage.esoterica) stage.esoterica.forEach(e => gainParts.push(e.name));
      if (stage.spells) stage.spells.forEach(s => gainParts.push(s.name));
      if (stage.weapons) stage.weapons.forEach(w => gainParts.push(w.name));
      if (stage.armor) stage.armor.forEach(a => gainParts.push(a.name));
      if (stage.shields) stage.shields.forEach(sh => gainParts.push(sh.name));
      if (stage.gear) stage.gear.forEach(g => gainParts.push(g.name));

      if (stage.description) {
          const gainLine = gainParts.length > 0 ? `\nGained: ${gainParts.join(", ")}` : "";
          this.oneRollState.biography.push(`**${stage.label}**: ${stage.description}${gainLine}`);
      }

      if (stage.attributes) {
          for (const [attr, val] of Object.entries(stage.attributes)) {
              if (this.draftCharacter.attributes[attr] !== undefined) {
                  this.draftCharacter.attributes[attr] = Math.min(5, this.draftCharacter.attributes[attr] + val);
              }
          }
      }

      const inferAttribute = (name, currentStage) => {
          const lower = name.toLowerCase();

          if (/athletics|endurance|fight|parry|run|vigor/.test(lower)) return "body";
          if (lower.includes("perform")) {
              if (currentStage?.attributes?.command) return "command";
              if (currentStage?.attributes?.coordination) return "coordination";
              return "command"; 
          }

          if (/climb|dodge|ride|stealth|weapon/.test(lower)) return "coordination";
          if (/direction|eerie|empathy|hearing|scrutinize|sight|taste|touch|smell/.test(lower)) return "sense";
          if (/counterspell|healing|language|lore|strategy|student|tactics/.test(lower)) return "knowledge";
          if (/haggle|inspire|intimidate/.test(lower)) return "command";
          if (/fascinate|graces|jest|lie|plead/.test(lower)) return "charm";

          return "knowledge"; 
      };

      const addSkillBonus = (skillKey, val, nameOverride = null) => {
          const lowerKey = skillKey.toLowerCase();
          const isForcedCustom = /perform|weapon|student|languageother/.test(lowerKey);

          if (!isForcedCustom && this.draftCharacter.skills[skillKey]) {
              this.draftCharacter.skills[skillKey].value = Math.min(5, this.draftCharacter.skills[skillKey].value + val);
          } else if (skillKey === "sorcery") {
              this.draftCharacter.sorcery.value = Math.min(5, this.draftCharacter.sorcery.value + val);
          } else {
              let name = nameOverride || skillKey.replace(/_/g, ': ').replace(/\b\w/g, l => l.toUpperCase());
              if (lowerKey === "languageother") name = "Language: Other";
              
              let existingKey = Object.keys(this.draftCharacter.customSkills).find(k => this.draftCharacter.customSkills[k].name.toLowerCase() === name.toLowerCase());
              
              if (existingKey) {
                  this.draftCharacter.customSkills[existingKey].value = Math.min(5, this.draftCharacter.customSkills[existingKey].value + val);
              } else {
                  const key = `custom_${foundry.utils.randomID(6)}`;
                  this.draftCharacter.customSkills[key] = {
                      name: name,
                      value: Math.min(5, val),
                      expert: false,
                      master: false,
                      attribute: inferAttribute(name, stage)
                  };
              }
          }
      };

      if (stage.skills) {
          for (const [skill, val] of Object.entries(stage.skills)) {
              addSkillBonus(skill, val);
          }
      }

      if (stage.customSkills) {
          for (const cs of stage.customSkills) {
              addSkillBonus(cs.name, cs.value || 1, cs.name);
          }
      }

      if (stage.wealth) {
          this.draftCharacter.wealth += stage.wealth;
      }

      const listMap = { advantages: "advantage", problems: "problem", martialPaths: "technique", esoterica: "discipline", spells: "spell", weapons: "weapon", armor: "armor", shields: "shield", gear: "gear" };
      for (const [list, type] of Object.entries(listMap)) {
          if (stage[list]) {
              for (const item of stage[list]) {
                  const foundItem = await this._findItem(item.name, type);
                  
                  if (foundItem) {
                      const safeItem = new Item.implementation(foundItem.toObject());
                      const itemData = safeItem.toObject();
                      itemData._draftId = foundry.utils.randomID();
                      if (item.system) itemData.system = foundry.utils.mergeObject(itemData.system, item.system);
                      this.draftCharacter[list].push(itemData);
                  } else {
                      this.draftCharacter[list].push({
                          _draftId: foundry.utils.randomID(),
                          name: `[PLACEHOLDER] ${item.name}`,
                          type: type,
                          system: item.system || {}
                      });
                  }
              }
          }
      }

      if (stage.special) {
           this.oneRollState.biography.push(`*(Special)*: ${stage.special}`);
           const specLower = stage.special.toLowerCase();

           if (specLower.includes("lose the normal master die")) {
               if(this.draftCharacter.skills.languageNative) this.draftCharacter.skills.languageNative.master = false;
           }

           const checkAndUpgrade = (keyword, isMaster) => {
               if (specLower.includes(keyword)) {
                   const targetSkill = Object.keys(this.draftCharacter.skills).find(k => k.toLowerCase().includes(keyword)) 
                       || (keyword === "sorcery" ? "sorcery" : null);
                       
                   if (targetSkill && targetSkill !== "sorcery") {
                       if (isMaster) { this.draftCharacter.skills[targetSkill].master = true; this.draftCharacter.skills[targetSkill].expert = false; }
                       else this.draftCharacter.skills[targetSkill].expert = true;
                   } else if (targetSkill === "sorcery") {
                       if (isMaster) { this.draftCharacter.sorcery.master = true; this.draftCharacter.sorcery.expert = false; }
                       else this.draftCharacter.sorcery.expert = true;
                   } else {
                       const cKey = Object.keys(this.draftCharacter.customSkills).find(k => this.draftCharacter.customSkills[k].name.toLowerCase().includes(keyword));
                       if (cKey) {
                           if (isMaster) { this.draftCharacter.customSkills[cKey].master = true; this.draftCharacter.customSkills[cKey].expert = false; }
                           else this.draftCharacter.customSkills[cKey].expert = true;
                       }
                   }
               }
           };

           const isMasterUpgrade = specLower.includes("to a master die") || specLower.includes("into a master die");
           const isExpertUpgrade = (specLower.includes("expert die") || specLower.includes("an expert")) && !isMasterUpgrade;

           if (isExpertUpgrade || isMasterUpgrade) {
               ["stealth", "climb", "perform", "fascinate", "haggle", "survival", "fight", "sword", "lore", "sorcery", "intimidate", "ride", "dodge", "parry"].forEach(kw => {
                   checkAndUpgrade(kw, isMasterUpgrade);
               });
               
               if (specLower.includes("change your expert die into a master die") || specLower.includes("change one expert die to a master die")) {
                   let upgraded = false;
                   for (let s of Object.values(this.draftCharacter.skills)) {
                       if (s.expert && !upgraded) { s.expert = false; s.master = true; upgraded = true; }
                   }
                   if (!upgraded && this.draftCharacter.sorcery.expert) {
                       this.draftCharacter.sorcery.expert = false; this.draftCharacter.sorcery.master = true; upgraded = true;
                   }
                   if (!upgraded) {
                       for (let s of Object.values(this.draftCharacter.customSkills)) {
                           if (s.expert && !upgraded) { s.expert = false; s.master = true; upgraded = true; }
                       }
                   }
               }
           }
      }
  }

  async _onRollTheBones(event, target) {
      event.preventDefault(); 
      
      const selectElement = this.element.querySelector("#oneroll-table-select");
      const selectedPath = selectElement ? selectElement.value : `systems/${game.system.id}/data/oneroll-default.json`;
      this.oneRollState.selectedTable = selectedPath;

      const table = await this._loadOneRollTable(selectedPath);
      if (!table) return;

      const roll = new Roll("11d10");
      await roll.evaluate();
      const dice = roll.terms[0].results.map(r => r.result).sort((a,b) => a - b);

      const counts = {};
      dice.forEach(d => counts[d] = (counts[d] || 0) + 1);

      const sets = [];
      const waste = [];

      for (let i = 1; i <= 10; i++) {
          const count = counts[i] || 0;
          if (count >= 2) {
              sets.push({ height: i, width: Math.min(count, 5) });
          } else if (count === 1) {
              waste.push(i);
          }
      }

      this.oneRollState.rolled = true;
      this.oneRollState.dice = dice;
      this.oneRollState.sets = sets;
      this.oneRollState.waste = waste;
      this.oneRollState.wasteChoices = {};
      this.oneRollState.biography = [];

      await this._applyOneRollSets(table);
      await this.render(true);
  }

  async _onSelectWasteChart(event, target) {
      event.preventDefault(); 
      const die = target.dataset.die;
      const chart = target.dataset.chart;

      this.oneRollState.wasteChoices[die] = chart;
      
      const selectElement = this.element.querySelector("#oneroll-table-select");
      const selectedPath = selectElement ? selectElement.value : `systems/${game.system.id}/data/oneroll-default.json`;
      this.oneRollState.selectedTable = selectedPath;

      const table = await this._loadOneRollTable(selectedPath);
      if(table) await this._applyOneRollSets(table);
      await this.render(true);
  }

  async _onChangeTable(event, target) {
      event.preventDefault(); 
      this.oneRollState.selectedTable = target.value;
  }

  async _onAcceptFate(event, target) {
       event.preventDefault();
       this.oneRollState.finalBio = this._buildFinalBiography();
       await this._onFinishCharacter(event, target);
  }

  /**
   * D3: Builds a structured biography string from the one-roll biography entries
   * and the final draft character state. Produces:
   *   - One paragraph per life path stage (description + gains)
   *   - Special events clearly marked
   *   - A summary block: total wealth, advantages, equipment
   */
  _buildFinalBiography() {
      const sections = this.oneRollState.biography;
      const dc = this.draftCharacter;

      // Stage paragraphs — already formatted in _applyStageGains
      const storyLines = sections.join("\n\n");

      // Summary block
      const summaryParts = [];

      // Wealth
      if (dc.wealth > 0) summaryParts.push(`Wealth: ${dc.wealth}`);

      // Advantages
      if (dc.advantages?.length > 0) {
          summaryParts.push(`Advantages: ${dc.advantages.map(a => a.name.replace(/\[PLACEHOLDER\] /, "")).join(", ")}`);
      }

      // Problems
      if (dc.problems?.length > 0) {
          summaryParts.push(`Problems: ${dc.problems.map(p => p.name.replace(/\[PLACEHOLDER\] /, "")).join(", ")}`);
      }

      // Equipment (weapons, armour, shields, gear combined)
      const equipment = [
          ...(dc.weapons  || []).map(w => w.name.replace(/\[PLACEHOLDER\] /, "")),
          ...(dc.armor    || []).map(a => a.name.replace(/\[PLACEHOLDER\] /, "")),
          ...(dc.shields  || []).map(s => s.name.replace(/\[PLACEHOLDER\] /, "")),
          ...(dc.gear     || []).map(g => g.name.replace(/\[PLACEHOLDER\] /, ""))
      ];
      if (equipment.length > 0) summaryParts.push(`Equipment: ${equipment.join(", ")}`);

      // Martial paths & esoterica
      if (dc.martialPaths?.length > 0) {
          summaryParts.push(`Martial Paths: ${dc.martialPaths.map(m => m.name.replace(/\[PLACEHOLDER\] /, "")).join(", ")}`);
      }
      if (dc.esoterica?.length > 0) {
          summaryParts.push(`Esoterica: ${dc.esoterica.map(e => e.name.replace(/\[PLACEHOLDER\] /, "")).join(", ")}`);
      }
      if (dc.spells?.length > 0) {
          summaryParts.push(`Spells: ${dc.spells.map(s => s.name.replace(/\[PLACEHOLDER\] /, "")).join(", ")}`);
      }

      const summaryBlock = summaryParts.length > 0
          ? `\n\n--- Character Summary ---\n${summaryParts.join("\n")}`
          : "";

      return storyLines + summaryBlock;
  }

  async _handleItemDrop(event) {
      let data;
      try { data = foundry.applications.ux.TextEditor.implementation.getDragEventData(event); } 
      catch(err) { data = JSON.parse(event.dataTransfer.getData("text/plain")); }
      
      if (data.type !== "Item") return;
      const item = await Item.implementation.fromDropData(data);
      if (!item) return;

      const safeItem = new Item.implementation(item.toObject());
      const itemData = safeItem.toObject();
      itemData._draftId = foundry.utils.randomID();
      
      let listName = "";
      if (item.type === "advantage") listName = "advantages";
      else if (item.type === "problem") listName = "problems";
      else if (item.type === "technique") listName = "martialPaths";
      else if (item.type === "discipline") listName = "esoterica";
      else if (item.type === "spell") {
          listName = "spells";
          if ((Number(item.system.intensity) || 1) > 10) return ui.notifications.error(game.i18n.localize("REIGN.CM.Errors.SpellsTooHigh") || "Intensity too high.");
      }
      else if (item.type === "weapon") listName = "weapons";
      else if (item.type === "armor") listName = "armor";
      else if (item.type === "shield") listName = "shields";
      else if (item.type === "gear") listName = "gear";
      else { return ui.notifications.warn(game.i18n.localize("REIGN.CM.Errors.InvalidItemType")); }

      if (listName === "problems" && this.draftCharacter.problems.length >= 3) return ui.notifications.error(game.i18n.localize("REIGN.CM.Errors.MaxProblems"));

      if (listName === "martialPaths" || listName === "esoterica") {
          if (listName === "martialPaths" && this.draftCharacter.martialPaths.length >= 15) return ui.notifications.error(game.i18n.localize("REIGN.CM.Errors.MaxTechniques") || "Maximum 15 Martial Techniques permitted.");
          if (listName === "esoterica" && this.draftCharacter.esoterica.length >= 15) return ui.notifications.error(game.i18n.localize("REIGN.CM.Errors.MaxDisciplines") || "Maximum 15 Esoteric Disciplines permitted.");

          const rank = parseInt(itemData.system.rank) || 1;
          const pathName = itemData.system.path?.trim().toLowerCase();
          if (pathName && rank > 1) {
              for (let req = 1; req < rank; req++) {
                  if (!this.draftCharacter[listName].some(i => i.system.path?.trim().toLowerCase() === pathName && parseInt(i.system.rank) === req)) {
                      return ui.notifications.error(`Cannot add "${item.name}". You must purchase Rank ${req} of the "${itemData.system.path}" path first!`);
                  }
              }
          }
      }

      this.draftCharacter[listName].push(itemData);
      this._calculatePoints();

      if (this.draftCharacter.pointsSpent > this.draftCharacter.pointsMax && listName !== "problems") {
          this.draftCharacter[listName].pop();
          this._calculatePoints();
          return ui.notifications.error(game.i18n.localize("REIGN.CM.Errors.NotEnoughPoints"));
      }

      await this.render(true);
  }

  async _onRemoveItem(event, target) {
      event.preventDefault(); 
      const list = target.dataset.list;
      const draftId = target.dataset.id;
      if (!this.draftCharacter[list]) return;
      this.draftCharacter[list] = this.draftCharacter[list].filter(i => i._draftId !== draftId);
      this._calculatePoints();
      await this.render(true);
  }

  async _onSelectPath(event, target) {
    event.preventDefault(); 
    this.creationPath = target.dataset.path;
    if (this.creationPath === "manual") {
      await this.actor.update({ "system.creationMode": false });
      this.actor.sheet.render(true);
      this.close();
    } else if (this.creationPath === "oneroll") {
      this.draftCharacter.attributes = { body: 2, coordination: 2, sense: 2, knowledge: 2, command: 2, charm: 2 };
      await this.render(true);
    } else {
      await this.render(true); 
    }
  }

  async _onChangeBudget(event, target) {
      event.preventDefault(); 
      this.draftCharacter.pointsMax = parseInt(target.value) || 85;
      await this.render(true);
  }

  async _onAdjustStat(event, target) {
    event.preventDefault(); 
    const type = target.dataset.type, key = target.dataset.key, isIncrease = target.dataset.dir === "up";
    let currentVal;
    if (type === "skill") currentVal = this.draftCharacter.skills[key].value;
    else if (type === "customSkill") currentVal = this.draftCharacter.customSkills[key].value;
    else if (type === "sorcery") currentVal = this.draftCharacter.sorcery.value;
    else if (type === "wealth") currentVal = this.draftCharacter.wealth;
    else currentVal = this.draftCharacter.attributes[key];

    // V14 FIX: Lock Native Language to a minimum value of 1.
    const maxVal = 5, minVal = type === "attribute" ? 1 : (key === "languageNative" ? 1 : 0);

    if (isIncrease) {
        if (currentVal >= maxVal) return; 
        if (type === "skill") this.draftCharacter.skills[key].value++;
        else if (type === "customSkill") this.draftCharacter.customSkills[key].value++;
        else if (type === "sorcery") this.draftCharacter.sorcery.value++;
        else if (type === "wealth") this.draftCharacter.wealth++;
        else this.draftCharacter.attributes[key]++;
        
        this._calculatePoints();
        if (this.draftCharacter.pointsSpent > this.draftCharacter.pointsMax) {
            if (type === "skill") this.draftCharacter.skills[key].value--;
            else if (type === "customSkill") this.draftCharacter.customSkills[key].value--;
            else if (type === "sorcery") this.draftCharacter.sorcery.value--;
            else if (type === "wealth") this.draftCharacter.wealth--;
            else this.draftCharacter.attributes[key]--;
            this._calculatePoints();
            return ui.notifications.error(game.i18n.localize("REIGN.CM.Errors.NotEnoughPoints"));
        }
    } else {
        if (currentVal <= minVal) return;
        
        if (type === "skill") {
            this.draftCharacter.skills[key].value--;
            if (this.draftCharacter.skills[key].value === 0 && key !== "languageNative") {
                this.draftCharacter.skills[key].expert = false;
                this.draftCharacter.skills[key].master = false;
            }
        }
        else if (type === "customSkill") {
            this.draftCharacter.customSkills[key].value--;
            if (this.draftCharacter.customSkills[key].value === 0) {
                this.draftCharacter.customSkills[key].expert = false;
                this.draftCharacter.customSkills[key].master = false;
            }
        }
        else if (type === "sorcery") {
            this.draftCharacter.sorcery.value--;
            if (this.draftCharacter.sorcery.value === 0) {
                this.draftCharacter.sorcery.expert = false;
                this.draftCharacter.sorcery.master = false;
                this.draftCharacter.school = null; // no sorcery → no school
            }
        }
        else if (type === "wealth") this.draftCharacter.wealth--;
        else this.draftCharacter.attributes[key]--;
        
        this._calculatePoints();
    }
    await this.render(true);
  }

  async _onToggleUpgrade(event, target) {
      event.preventDefault(); 
      const type = target.dataset.type, key = target.dataset.key, upgradeType = target.dataset.upgrade; 
      let skill;
      if (type === "customSkill") skill = this.draftCharacter.customSkills[key];
      else if (type === "sorcery") skill = this.draftCharacter.sorcery;
      else skill = this.draftCharacter.skills[key];

      if (!skill) return;
      if (key === "languageNative") return ui.notifications.warn(game.i18n.localize("REIGN.CM.Errors.NativeLanguageLocked"));

      if (skill.value < 1) {
          return ui.notifications.warn(game.i18n.localize("REIGN.CM.Errors.UpgradeRequiresValue") || "You must have at least 1 regular die in a Skill to upgrade it to Expert or Master.");
      }

      const prevExp = skill.expert, prevMas = skill.master;
      if (upgradeType === "expert") { skill.expert = !skill.expert; if (skill.expert) skill.master = false; } 
      else if (upgradeType === "master") { skill.master = !skill.master; if (skill.master) skill.expert = false; }

      this._calculatePoints();
      if (this.draftCharacter.pointsSpent > this.draftCharacter.pointsMax) {
          skill.expert = prevExp; skill.master = prevMas;
          this._calculatePoints();
          return ui.notifications.error(game.i18n.localize("REIGN.CM.Errors.NotEnoughPoints"));
      }
      await this.render(true);
  }

  async _onAddCustomSkill(event, target) {
      event.preventDefault(); 
      const attr = target.dataset.attr; 
      const input = this.element.querySelector(`#new-skill-${attr}`);
      const name = input ? input.value.trim() : "";
      if (!name) return ui.notifications.warn(game.i18n.localize("REIGN.CM.Errors.EnterName"));
      const key = `custom_${foundry.utils.randomID(6)}`;
      this.draftCharacter.customSkills[key] = { name: name, value: 0, expert: false, master: false, attribute: attr };
      this._calculatePoints();
      await this.render(true);
  }

  async _onRemoveCustomSkill(event, target) {
      event.preventDefault(); 
      const key = target.dataset.key;
      if (!key || !this.draftCharacter.customSkills[key]) return;
      delete this.draftCharacter.customSkills[key];
      this._calculatePoints();
      await this.render(true);
  }

  async _onSelectSchool(event, target) {
      event.preventDefault();
      const schoolId = target.dataset.schoolId;
      if (!schoolId) return;

      // If clicking the already-selected school, deselect it (allow generalist)
      if (this.draftCharacter.school?.id === schoolId) {
          this.draftCharacter.school = null;
          await this.render(true);
          return;
      }

      // Load the school definition from the active table JSON
      const tablesSetting = game.settings.get("reign", "oneRollTables") || `systems/${game.system.id}/data/oneroll-default.json`;
      const primaryPath = tablesSetting.split(",").map(p => p.trim()).filter(p => p)[0];
      if (!primaryPath) return;

      const table = await this._loadOneRollTable(primaryPath);
      const school = table?.schools?.find(s => s.id === schoolId);
      if (!school) return;

      this.draftCharacter.school = school;
      await this.render(true);
  }

  async _onFinishCharacter(event, target) {
      event.preventDefault(); 
      const updates = {
          "system.creationMode": false, 
          "system.wealth.value": this.draftCharacter.wealth,
          "system.attributes.body.value": this.draftCharacter.attributes.body,
          "system.attributes.coordination.value": this.draftCharacter.attributes.coordination,
          "system.attributes.sense.value": this.draftCharacter.attributes.sense,
          "system.attributes.knowledge.value": this.draftCharacter.attributes.knowledge,
          "system.attributes.command.value": this.draftCharacter.attributes.command,
          "system.attributes.charm.value": this.draftCharacter.attributes.charm,
          "system.esoterica.sorcery": this.draftCharacter.sorcery.value,
          "system.esoterica.expert": this.draftCharacter.sorcery.expert,
          "system.esoterica.master": this.draftCharacter.sorcery.master
      };

      // Apply selected magical school if one was chosen
      if (this.draftCharacter.school) {
          const s = this.draftCharacter.school;
          updates["system.esoterica.schoolName"]   = s.name   || "";
          updates["system.esoterica.schoolDomain"] = s.domain || "";
          updates["system.esoterica.schoolMethod"] = s.method || "";
          updates["system.esoterica.schoolStat"]   = s.associatedStat || "";
          // Seed attunement notes with the school's attunement description so
          // the GM/player has a prompt to work from; they can edit it freely.
          if (s.attunementNote) {
              updates["system.esoterica.attunement"] = s.attunementNote;
          }
      }

      if (this.creationPath === "oneroll" && this.oneRollState.finalBio) {
          updates["system.biography.history"] = this.oneRollState.finalBio;
      }

      for (const [key, skill] of Object.entries(this.draftCharacter.skills)) {
          updates[`system.skills.${key}.value`] = skill.value;
          updates[`system.skills.${key}.expert`] = skill.expert;
          updates[`system.skills.${key}.master`] = skill.master;
      }

      for (const [key, skill] of Object.entries(this.draftCharacter.customSkills)) {
          updates[`system.customSkills.${key}`] = {
              customLabel: skill.name, 
              value: skill.value, expert: skill.expert, master: skill.master,
              attribute: skill.attribute, isCombat: false
          };
      }

      await this.actor.update(updates);

      const itemsToCreate = [];
      const itemLists = ["advantages", "problems", "martialPaths", "esoterica", "spells", "weapons", "armor", "shields", "gear"];
      for (const list of itemLists) {
          if (!this.draftCharacter[list]) continue;
          for (const item of this.draftCharacter[list]) {
              const cleanItem = foundry.utils.deepClone(item);
              delete cleanItem._draftId; 
              delete cleanItem._id; 
              itemsToCreate.push(cleanItem);
          }
      }
      
      if (itemsToCreate.length > 0) {
          await this.actor.createEmbeddedDocuments("Item", itemsToCreate, { keepId: false });
      }

      ui.notifications.success(`${this.actor.name} ${game.i18n.localize("REIGN.CM.Errors.ForgedSuccess") || "has been successfully forged!"}`);
      this.actor.sheet.render(true);
      this.close();
  }
}